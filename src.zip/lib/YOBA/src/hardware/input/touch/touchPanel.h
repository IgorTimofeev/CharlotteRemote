#pragma once

#include "../inputDevice.h"

namespace yoba {
	class TouchPanel : public InputDevice {

	};
}