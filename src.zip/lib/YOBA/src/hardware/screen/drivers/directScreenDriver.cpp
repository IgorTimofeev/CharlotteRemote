#include "directScreenDriver.h"

namespace yoba {
	DirectScreenDriver::DirectScreenDriver() { // NOLINT(*-use-equals-default)

	}
}