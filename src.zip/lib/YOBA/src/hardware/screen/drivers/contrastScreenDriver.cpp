#include "contrastScreenDriver.h"

namespace yoba {
	ContrastScreenDriver::ContrastScreenDriver() { // NOLINT(*-use-equals-default)

	}
}
